
### Installation
```
./setup.sh
```

### Compilation run
```
./distributed_train.sh
```
